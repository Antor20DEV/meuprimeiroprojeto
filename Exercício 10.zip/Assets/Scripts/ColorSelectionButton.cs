using UnityEngine;
using UnityEngine.UI;

public class ColorSelectionButton : MonoBehaviour
{
    public Button uiButton;
    public Image paddleReference;

    public bool isColorPlayer = false;

    public void OnButtonClick()
    {
        Debug.Log("Bot�o de cor clicado!");
        paddleReference.color = uiButton.colors.normalColor;

        if (isColorPlayer)
        {
            SaveController.Instance.colorPlayer = paddleReference.color;
            Debug.Log("Cor salva no SaveController: ");
        }
        else
        {
            SaveController.Instance.colorEnemy = paddleReference.color;
        }
    }
}
